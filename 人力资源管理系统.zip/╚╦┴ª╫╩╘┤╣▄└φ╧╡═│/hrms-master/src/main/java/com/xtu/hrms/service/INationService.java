package com.xtu.hrms.service;

import com.xtu.hrms.bean.Nation;

import java.util.List;

public interface INationService {
    List<Nation> getAllNations();
}
