/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50735
Source Host           : localhost:3306
Source Database       : sale

Target Server Type    : MYSQL
Target Server Version : 50735
File Encoding         : 65001

Date: 2022-02-26 09:30:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(10) NOT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('1', '管理员');
INSERT INTO `t_role` VALUES ('2', '评委');
INSERT INTO `t_role` VALUES ('3', '销售');

-- ----------------------------
-- Table structure for t_sales
-- ----------------------------
DROP TABLE IF EXISTS `t_sales`;
CREATE TABLE `t_sales` (
  `salesid` int(11) NOT NULL AUTO_INCREMENT,
  `salesname` varchar(10) NOT NULL,
  PRIMARY KEY (`salesid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_sales
-- ----------------------------
INSERT INTO `t_sales` VALUES ('1', '张三');
INSERT INTO `t_sales` VALUES ('2', '李四');
INSERT INTO `t_sales` VALUES ('3', '王五');
INSERT INTO `t_sales` VALUES ('4', '赵六');

-- ----------------------------
-- Table structure for t_score
-- ----------------------------
DROP TABLE IF EXISTS `t_score`;
CREATE TABLE `t_score` (
  `scoreid` int(11) NOT NULL AUTO_INCREMENT,
  `salesid` int(11) NOT NULL,
  `score1` int(11) NOT NULL,
  `score2` int(11) NOT NULL,
  `score3` int(11) NOT NULL,
  `score4` int(11) NOT NULL,
  `score5` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`scoreid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_score
-- ----------------------------
INSERT INTO `t_score` VALUES ('1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `t_score` VALUES ('2', '1', '2', '2', '2', '2', '2', '2');
INSERT INTO `t_score` VALUES ('3', '2', '5', '5', '5', '5', '5', '1');
INSERT INTO `t_score` VALUES ('4', '2', '1', '2', '3', '4', '5', '2');
INSERT INTO `t_score` VALUES ('5', '3', '5', '4', '3', '2', '1', '1');
INSERT INTO `t_score` VALUES ('6', '4', '3', '3', '3', '3', '3', '2');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `roleid` int(11) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'admin', '123456', '1');
INSERT INTO `t_user` VALUES ('2', 'test', '456', '2');
INSERT INTO `t_user` VALUES ('3', 'abc', '789', '3');
